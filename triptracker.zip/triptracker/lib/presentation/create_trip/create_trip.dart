import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/trip_form_widget.dart';
import './widgets/trip_header_widget.dart';

class CreateTrip extends StatefulWidget {
  const CreateTrip({Key? key}) : super(key: key);

  @override
  State<CreateTrip> createState() => _CreateTripState();
}

class _CreateTripState extends State<CreateTrip> {
  Map<String, dynamic> _formData = {};
  bool _isFormValid = false;

  // Mock data for demonstration
  final List<Map<String, dynamic>> _existingTrips = [
    {
      "id": 1,
      "name": "Tokyo Business Trip",
      "destination": "Tokyo, Japan",
      "startDate": DateTime(2025, 1, 15),
      "endDate": DateTime(2025, 1, 22),
      "budget": 3500.0,
      "currency": "USD",
      "category": "Business",
      "notes": "Annual conference and client meetings",
      "totalExpenses": 2847.50,
      "status": "upcoming"
    },
    {
      "id": 2,
      "name": "European Adventure",
      "destination": "Paris, France",
      "startDate": DateTime(2024, 12, 20),
      "endDate": DateTime(2025, 1, 5),
      "budget": 4200.0,
      "currency": "EUR",
      "category": "Leisure",
      "notes": "Christmas vacation with family",
      "totalExpenses": 3890.25,
      "status": "completed"
    }
  ];

  @override
  void initState() {
    super.initState();
    _validateForm();
  }

  void _onFormChanged(Map<String, dynamic> formData) {
    setState(() {
      _formData = formData;
      _validateForm();
    });
  }

  void _validateForm() {
    final tripName = _formData['tripName'] as String?;
    final destination = _formData['destination'] as String?;
    final startDate = _formData['startDate'] as DateTime?;
    final endDate = _formData['endDate'] as DateTime?;

    _isFormValid = tripName != null &&
        tripName.trim().isNotEmpty &&
        destination != null &&
        destination.trim().isNotEmpty &&
        startDate != null &&
        endDate != null &&
        !endDate.isBefore(startDate);
  }

  void _onCancel() {
    // Show confirmation dialog if form has data
    if (_formData.isNotEmpty &&
        (_formData['tripName']?.toString().isNotEmpty == true ||
            _formData['destination']?.toString().isNotEmpty == true)) {
      _showCancelConfirmationDialog();
    } else {
      Navigator.pop(context);
    }
  }

  void _showCancelConfirmationDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: AppTheme.dialogColor,
          title: Text(
            'Discard Changes?',
            style: AppTheme.darkTheme.textTheme.titleLarge,
          ),
          content: Text(
            'You have unsaved changes. Are you sure you want to discard them?',
            style: AppTheme.darkTheme.textTheme.bodyMedium,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                'Keep Editing',
                style: TextStyle(color: AppTheme.textSecondary),
              ),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context); // Close dialog
                Navigator.pop(context); // Close create trip screen
              },
              child: Text(
                'Discard',
                style: TextStyle(color: AppTheme.errorColor),
              ),
            ),
          ],
        );
      },
    );
  }

  void _onSave() {
    if (!_isFormValid) return;

    // Provide haptic feedback
    HapticFeedback.lightImpact();

    // Create new trip data
    final newTrip = {
      "id": _existingTrips.length + 1,
      "name": _formData['tripName'],
      "destination": _formData['destination'],
      "startDate": _formData['startDate'],
      "endDate": _formData['endDate'],
      "budget": _formData['budget']?.isNotEmpty == true
          ? double.tryParse(_formData['budget']) ?? 0.0
          : 0.0,
      "currency": _formData['currency'] ?? 'USD',
      "category": _formData['category'] ?? 'Leisure',
      "notes": _formData['notes'] ?? '',
      "totalExpenses": 0.0,
      "status": "upcoming",
      "createdAt": DateTime.now(),
    };

    // Show success message
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(
              iconName: 'check_circle',
              color: AppTheme.successColor,
              size: 20,
            ),
            SizedBox(width: 2.w),
            Expanded(
              child: Text(
                'Trip "${newTrip['name']}" created successfully!',
                style: AppTheme.darkTheme.textTheme.bodyMedium,
              ),
            ),
          ],
        ),
        backgroundColor: AppTheme.secondaryDark,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 3),
      ),
    );

    // Navigate to trip detail or dashboard
    Future.delayed(const Duration(milliseconds: 500), () {
      Navigator.pushReplacementNamed(context, '/trip-dashboard');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.primaryDark,
      body: Column(
        children: [
          // Header
          TripHeaderWidget(
            onCancel: _onCancel,
            onSave: _onSave,
            isSaveEnabled: _isFormValid,
          ),

          // Form Content
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(4.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Welcome Message
                  Container(
                    width: double.infinity,
                    padding: EdgeInsets.all(4.w),
                    margin: EdgeInsets.only(bottom: 3.h),
                    decoration: BoxDecoration(
                      color: AppTheme.accentColor.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: AppTheme.accentColor.withValues(alpha: 0.3),
                      ),
                    ),
                    child: Row(
                      children: [
                        CustomIconWidget(
                          iconName: 'info_outline',
                          color: AppTheme.accentColor,
                          size: 24,
                        ),
                        SizedBox(width: 3.w),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Plan Your Next Adventure',
                                style: AppTheme.darkTheme.textTheme.titleMedium
                                    ?.copyWith(
                                  color: AppTheme.accentColor,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              SizedBox(height: 0.5.h),
                              Text(
                                'Fill in the details below to create your trip and start tracking expenses.',
                                style: AppTheme.darkTheme.textTheme.bodySmall
                                    ?.copyWith(
                                  color: AppTheme.textSecondary,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Trip Form
                  TripFormWidget(
                    onFormChanged: _onFormChanged,
                    onSave: _onSave,
                    isFormValid: _isFormValid,
                  ),

                  SizedBox(height: 4.h),

                  // Form Validation Status
                  if (!_isFormValid && _formData.isNotEmpty)
                    Container(
                      width: double.infinity,
                      padding: EdgeInsets.all(3.w),
                      decoration: BoxDecoration(
                        color: AppTheme.errorColor.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: AppTheme.errorColor.withValues(alpha: 0.3),
                        ),
                      ),
                      child: Row(
                        children: [
                          CustomIconWidget(
                            iconName: 'warning',
                            color: AppTheme.errorColor,
                            size: 20,
                          ),
                          SizedBox(width: 2.w),
                          Expanded(
                            child: Text(
                              'Please fill in all required fields to save your trip.',
                              style: AppTheme.darkTheme.textTheme.bodySmall
                                  ?.copyWith(
                                color: AppTheme.errorColor,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                  SizedBox(height: 2.h),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

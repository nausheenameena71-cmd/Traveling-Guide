import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class TripFormWidget extends StatefulWidget {
  final Function(Map<String, dynamic>) onFormChanged;
  final VoidCallback? onSave;
  final bool isFormValid;

  const TripFormWidget({
    Key? key,
    required this.onFormChanged,
    this.onSave,
    required this.isFormValid,
  }) : super(key: key);

  @override
  State<TripFormWidget> createState() => _TripFormWidgetState();
}

class _TripFormWidgetState extends State<TripFormWidget> {
  final _formKey = GlobalKey<FormState>();
  final _tripNameController = TextEditingController();
  final _destinationController = TextEditingController();
  final _budgetController = TextEditingController();
  final _notesController = TextEditingController();

  DateTime? _startDate;
  DateTime? _endDate;
  String _selectedCurrency = 'USD';
  String _selectedCategory = 'Leisure';
  bool _showAdvancedOptions = false;

  final List<Map<String, String>> _currencies = [
    {'code': 'USD', 'symbol': '\$', 'flag': '🇺🇸'},
    {'code': 'EUR', 'symbol': '€', 'flag': '🇪🇺'},
    {'code': 'GBP', 'symbol': '£', 'flag': '🇬🇧'},
    {'code': 'JPY', 'symbol': '¥', 'flag': '🇯🇵'},
    {'code': 'CAD', 'symbol': 'C\$', 'flag': '🇨🇦'},
    {'code': 'AUD', 'symbol': 'A\$', 'flag': '🇦🇺'},
  ];

  final List<String> _categories = ['Business', 'Leisure', 'Mixed'];

  @override
  void initState() {
    super.initState();
    _tripNameController.addListener(_updateForm);
    _destinationController.addListener(_updateForm);
    _budgetController.addListener(_updateForm);
    _notesController.addListener(_updateForm);
  }

  @override
  void dispose() {
    _tripNameController.dispose();
    _destinationController.dispose();
    _budgetController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  void _updateForm() {
    final formData = {
      'tripName': _tripNameController.text,
      'destination': _destinationController.text,
      'startDate': _startDate,
      'endDate': _endDate,
      'budget': _budgetController.text,
      'currency': _selectedCurrency,
      'category': _selectedCategory,
      'notes': _notesController.text,
    };
    widget.onFormChanged(formData);
  }

  Future<void> _selectDate(BuildContext context, bool isStartDate) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: isStartDate
          ? (_startDate ?? DateTime.now())
          : (_endDate ?? _startDate ?? DateTime.now()),
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now().add(const Duration(days: 1095)),
      builder: (context, child) {
        return Theme(
          data: AppTheme.darkTheme,
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        if (isStartDate) {
          _startDate = picked;
          if (_endDate != null && _endDate!.isBefore(picked)) {
            _endDate = null;
          }
        } else {
          _endDate = picked;
        }
      });
      _updateForm();
    }
  }

  void _showCurrencyPicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.dialogColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) {
        return Container(
          height: 50.h,
          padding: EdgeInsets.all(4.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Select Currency',
                style: AppTheme.darkTheme.textTheme.titleLarge,
              ),
              SizedBox(height: 2.h),
              Expanded(
                child: ListView.builder(
                  itemCount: _currencies.length,
                  itemBuilder: (context, index) {
                    final currency = _currencies[index];
                    return ListTile(
                      leading: Text(
                        currency['flag']!,
                        style: TextStyle(fontSize: 20.sp),
                      ),
                      title: Text(
                        '${currency['code']} (${currency['symbol']})',
                        style: AppTheme.darkTheme.textTheme.bodyLarge,
                      ),
                      trailing: _selectedCurrency == currency['code']
                          ? CustomIconWidget(
                              iconName: 'check',
                              color: AppTheme.accentColor,
                              size: 20,
                            )
                          : null,
                      onTap: () {
                        setState(() {
                          _selectedCurrency = currency['code']!;
                        });
                        _updateForm();
                        Navigator.pop(context);
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Trip Name Field
          Text(
            'Trip Name *',
            style: AppTheme.darkTheme.textTheme.labelLarge,
          ),
          SizedBox(height: 1.h),
          TextFormField(
            controller: _tripNameController,
            style: AppTheme.darkTheme.textTheme.bodyLarge,
            decoration: InputDecoration(
              hintText: 'Enter trip name',
              prefixIcon: Padding(
                padding: EdgeInsets.all(3.w),
                child: CustomIconWidget(
                  iconName: 'flight_takeoff',
                  color: AppTheme.textSecondary,
                  size: 20,
                ),
              ),
            ),
            validator: (value) {
              if (value == null || value.trim().isEmpty) {
                return 'Trip name is required';
              }
              return null;
            },
          ),
          SizedBox(height: 3.h),

          // Destination Field
          Text(
            'Destination *',
            style: AppTheme.darkTheme.textTheme.labelLarge,
          ),
          SizedBox(height: 1.h),
          TextFormField(
            controller: _destinationController,
            style: AppTheme.darkTheme.textTheme.bodyLarge,
            decoration: InputDecoration(
              hintText: 'Where are you going?',
              prefixIcon: Padding(
                padding: EdgeInsets.all(3.w),
                child: CustomIconWidget(
                  iconName: 'location_on',
                  color: AppTheme.textSecondary,
                  size: 20,
                ),
              ),
              suffixIcon: IconButton(
                icon: CustomIconWidget(
                  iconName: 'search',
                  color: AppTheme.textSecondary,
                  size: 20,
                ),
                onPressed: () {
                  // Location picker integration would go here
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Location picker integration coming soon'),
                    ),
                  );
                },
              ),
            ),
            validator: (value) {
              if (value == null || value.trim().isEmpty) {
                return 'Destination is required';
              }
              return null;
            },
          ),
          SizedBox(height: 3.h),

          // Date Range Selector
          Text(
            'Travel Dates *',
            style: AppTheme.darkTheme.textTheme.labelLarge,
          ),
          SizedBox(height: 1.h),
          Row(
            children: [
              Expanded(
                child: InkWell(
                  onTap: () => _selectDate(context, true),
                  child: Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 4.w, vertical: 3.h),
                    decoration: BoxDecoration(
                      color: AppTheme.surfaceColor,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppTheme.borderColor),
                    ),
                    child: Row(
                      children: [
                        CustomIconWidget(
                          iconName: 'calendar_today',
                          color: AppTheme.textSecondary,
                          size: 20,
                        ),
                        SizedBox(width: 2.w),
                        Expanded(
                          child: Text(
                            _startDate != null
                                ? '${_startDate!.month}/${_startDate!.day}/${_startDate!.year}'
                                : 'Start Date',
                            style: _startDate != null
                                ? AppTheme.darkTheme.textTheme.bodyLarge
                                : AppTheme.darkTheme.textTheme.bodyLarge
                                    ?.copyWith(
                                    color: AppTheme.textDisabled,
                                  ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: InkWell(
                  onTap: () => _selectDate(context, false),
                  child: Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 4.w, vertical: 3.h),
                    decoration: BoxDecoration(
                      color: AppTheme.surfaceColor,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppTheme.borderColor),
                    ),
                    child: Row(
                      children: [
                        CustomIconWidget(
                          iconName: 'calendar_today',
                          color: AppTheme.textSecondary,
                          size: 20,
                        ),
                        SizedBox(width: 2.w),
                        Expanded(
                          child: Text(
                            _endDate != null
                                ? '${_endDate!.month}/${_endDate!.day}/${_endDate!.year}'
                                : 'End Date',
                            style: _endDate != null
                                ? AppTheme.darkTheme.textTheme.bodyLarge
                                : AppTheme.darkTheme.textTheme.bodyLarge
                                    ?.copyWith(
                                    color: AppTheme.textDisabled,
                                  ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 3.h),

          // Budget Field
          Text(
            'Budget (Optional)',
            style: AppTheme.darkTheme.textTheme.labelLarge,
          ),
          SizedBox(height: 1.h),
          Row(
            children: [
              InkWell(
                onTap: _showCurrencyPicker,
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 3.h),
                  decoration: BoxDecoration(
                    color: AppTheme.surfaceColor,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: AppTheme.borderColor),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        _currencies.firstWhere(
                            (c) => c['code'] == _selectedCurrency)['flag']!,
                        style: TextStyle(fontSize: 16.sp),
                      ),
                      SizedBox(width: 1.w),
                      Text(
                        _selectedCurrency,
                        style: AppTheme.darkTheme.textTheme.bodyLarge,
                      ),
                      SizedBox(width: 1.w),
                      CustomIconWidget(
                        iconName: 'keyboard_arrow_down',
                        color: AppTheme.textSecondary,
                        size: 16,
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: TextFormField(
                  controller: _budgetController,
                  style: AppTheme.darkTheme.textTheme.bodyLarge,
                  keyboardType: TextInputType.numberWithOptions(decimal: true),
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(
                        RegExp(r'^\d+\.?\d{0,2}')),
                  ],
                  decoration: InputDecoration(
                    hintText: '0.00',
                    prefixIcon: Padding(
                      padding: EdgeInsets.all(3.w),
                      child: CustomIconWidget(
                        iconName: 'attach_money',
                        color: AppTheme.textSecondary,
                        size: 20,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 3.h),

          // Advanced Options Toggle
          InkWell(
            onTap: () {
              setState(() {
                _showAdvancedOptions = !_showAdvancedOptions;
              });
            },
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 2.h),
              child: Row(
                children: [
                  CustomIconWidget(
                    iconName:
                        _showAdvancedOptions ? 'expand_less' : 'expand_more',
                    color: AppTheme.accentColor,
                    size: 20,
                  ),
                  SizedBox(width: 2.w),
                  Text(
                    'Advanced Options',
                    style: AppTheme.darkTheme.textTheme.bodyLarge?.copyWith(
                      color: AppTheme.accentColor,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Advanced Options Content
          if (_showAdvancedOptions) ...[
            SizedBox(height: 2.h),

            // Trip Category
            Text(
              'Trip Category',
              style: AppTheme.darkTheme.textTheme.labelLarge,
            ),
            SizedBox(height: 1.h),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 4.w),
              decoration: BoxDecoration(
                color: AppTheme.surfaceColor,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppTheme.borderColor),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: _selectedCategory,
                  isExpanded: true,
                  dropdownColor: AppTheme.surfaceColor,
                  style: AppTheme.darkTheme.textTheme.bodyLarge,
                  icon: CustomIconWidget(
                    iconName: 'keyboard_arrow_down',
                    color: AppTheme.textSecondary,
                    size: 20,
                  ),
                  items: _categories.map((String category) {
                    return DropdownMenuItem<String>(
                      value: category,
                      child: Row(
                        children: [
                          CustomIconWidget(
                            iconName: category == 'Business'
                                ? 'business_center'
                                : category == 'Leisure'
                                    ? 'beach_access'
                                    : 'category',
                            color: AppTheme.textSecondary,
                            size: 20,
                          ),
                          SizedBox(width: 2.w),
                          Text(category),
                        ],
                      ),
                    );
                  }).toList(),
                  onChanged: (String? newValue) {
                    if (newValue != null) {
                      setState(() {
                        _selectedCategory = newValue;
                      });
                      _updateForm();
                    }
                  },
                ),
              ),
            ),
            SizedBox(height: 3.h),

            // Notes Field
            Text(
              'Notes',
              style: AppTheme.darkTheme.textTheme.labelLarge,
            ),
            SizedBox(height: 1.h),
            TextFormField(
              controller: _notesController,
              style: AppTheme.darkTheme.textTheme.bodyLarge,
              maxLines: 3,
              decoration: InputDecoration(
                hintText: 'Add any additional notes about your trip...',
                prefixIcon: Padding(
                  padding: EdgeInsets.only(left: 3.w, top: 3.w),
                  child: CustomIconWidget(
                    iconName: 'note',
                    color: AppTheme.textSecondary,
                    size: 20,
                  ),
                ),
                alignLabelWithHint: true,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';

class TripHeaderWidget extends StatelessWidget {
  final VoidCallback onCancel;
  final VoidCallback? onSave;
  final bool isSaveEnabled;

  const TripHeaderWidget({
    Key? key,
    required this.onCancel,
    this.onSave,
    required this.isSaveEnabled,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      decoration: BoxDecoration(
        color: AppTheme.primaryDark,
        border: Border(
          bottom: BorderSide(
            color: AppTheme.borderColor,
            width: 1,
          ),
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            // Cancel Button
            TextButton(
              onPressed: onCancel,
              style: TextButton.styleFrom(
                foregroundColor: AppTheme.textSecondary,
                padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
              ),
              child: Text(
                'Cancel',
                style: AppTheme.darkTheme.textTheme.bodyLarge?.copyWith(
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),

            // Title
            Text(
              'Create Trip',
              style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),

            // Save Button
            TextButton(
              onPressed: isSaveEnabled ? onSave : null,
              style: TextButton.styleFrom(
                foregroundColor: isSaveEnabled
                    ? AppTheme.accentColor
                    : AppTheme.textDisabled,
                padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
              ),
              child: Text(
                'Save',
                style: AppTheme.darkTheme.textTheme.bodyLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: isSaveEnabled
                      ? AppTheme.accentColor
                      : AppTheme.textDisabled,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

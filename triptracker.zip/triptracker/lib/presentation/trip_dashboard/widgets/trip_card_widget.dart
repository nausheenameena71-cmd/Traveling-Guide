import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class TripCardWidget extends StatelessWidget {
  final Map<String, dynamic> tripData;
  final VoidCallback? onTap;
  final VoidCallback? onAddExpense;
  final VoidCallback? onArchive;
  final VoidCallback? onLongPress;

  const TripCardWidget({
    Key? key,
    required this.tripData,
    this.onTap,
    this.onAddExpense,
    this.onArchive,
    this.onLongPress,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final String destination =
        tripData['destination'] as String? ?? 'Unknown Destination';
    final String startDate = tripData['startDate'] as String? ?? '';
    final String endDate = tripData['endDate'] as String? ?? '';
    final double currentSpending =
        (tripData['currentSpending'] as num?)?.toDouble() ?? 0.0;
    final double budget = (tripData['budget'] as num?)?.toDouble() ?? 1.0;
    final String imageUrl = tripData['imageUrl'] as String? ?? '';
    final String category = tripData['category'] as String? ?? 'travel';
    final bool isActive = tripData['isActive'] as bool? ?? true;

    final double progressPercentage =
        budget > 0 ? (currentSpending / budget).clamp(0.0, 1.0) : 0.0;
    final Color progressColor = progressPercentage > 0.8
        ? AppTheme.errorColor
        : progressPercentage > 0.6
            ? AppTheme.warningColor
            : AppTheme.successColor;

    return Dismissible(
      key: Key('trip_${tripData['id']}'),
      background: Container(
        margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
        decoration: BoxDecoration(
          color: AppTheme.successColor.withValues(alpha: 0.2),
          borderRadius: BorderRadius.circular(12),
        ),
        alignment: Alignment.centerLeft,
        padding: EdgeInsets.only(left: 6.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CustomIconWidget(
              iconName: 'add_circle',
              color: AppTheme.successColor,
              size: 24,
            ),
            SizedBox(height: 0.5.h),
            Text(
              'Add Expense',
              style: AppTheme.darkTheme.textTheme.labelSmall?.copyWith(
                color: AppTheme.successColor,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
      secondaryBackground: Container(
        margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
        decoration: BoxDecoration(
          color: AppTheme.warningColor.withValues(alpha: 0.2),
          borderRadius: BorderRadius.circular(12),
        ),
        alignment: Alignment.centerRight,
        padding: EdgeInsets.only(right: 6.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CustomIconWidget(
              iconName: 'archive',
              color: AppTheme.warningColor,
              size: 24,
            ),
            SizedBox(height: 0.5.h),
            Text(
              'Archive',
              style: AppTheme.darkTheme.textTheme.labelSmall?.copyWith(
                color: AppTheme.warningColor,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
      onDismissed: (direction) {
        if (direction == DismissDirection.startToEnd && onAddExpense != null) {
          onAddExpense!();
        } else if (direction == DismissDirection.endToStart &&
            onArchive != null) {
          onArchive!();
        }
      },
      child: GestureDetector(
        onTap: onTap,
        onLongPress: onLongPress,
        child: Container(
          margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
          decoration: BoxDecoration(
            color: AppTheme.cardColor,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isActive
                  ? AppTheme.accentColor.withValues(alpha: 0.3)
                  : AppTheme.borderColor,
              width: 1,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Trip Image and Header
              ClipRRect(
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(12)),
                child: Stack(
                  children: [
                    imageUrl.isNotEmpty
                        ? CustomImageWidget(
                            imageUrl: imageUrl,
                            width: double.infinity,
                            height: 20.h,
                            fit: BoxFit.cover,
                          )
                        : Container(
                            width: double.infinity,
                            height: 20.h,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  AppTheme.accentColor.withValues(alpha: 0.3),
                                  AppTheme.successColor.withValues(alpha: 0.2),
                                ],
                              ),
                            ),
                            child: Center(
                              child: CustomIconWidget(
                                iconName: _getCategoryIcon(category),
                                color: AppTheme.textSecondary,
                                size: 48,
                              ),
                            ),
                          ),
                    // Status Badge
                    Positioned(
                      top: 2.h,
                      right: 4.w,
                      child: Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 3.w, vertical: 0.5.h),
                        decoration: BoxDecoration(
                          color: isActive
                              ? AppTheme.successColor.withValues(alpha: 0.9)
                              : AppTheme.textSecondary.withValues(alpha: 0.9),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          isActive ? 'Active' : 'Completed',
                          style:
                              AppTheme.darkTheme.textTheme.labelSmall?.copyWith(
                            color: AppTheme.textPrimary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // Trip Details
              Padding(
                padding: EdgeInsets.all(4.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Destination and Category
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            destination,
                            style: AppTheme.darkTheme.textTheme.titleMedium
                                ?.copyWith(
                              fontWeight: FontWeight.w600,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        CustomIconWidget(
                          iconName: _getCategoryIcon(category),
                          color: AppTheme.accentColor,
                          size: 20,
                        ),
                      ],
                    ),

                    SizedBox(height: 1.h),

                    // Dates
                    Row(
                      children: [
                        CustomIconWidget(
                          iconName: 'calendar_today',
                          color: AppTheme.textSecondary,
                          size: 16,
                        ),
                        SizedBox(width: 2.w),
                        Expanded(
                          child: Text(
                            '$startDate - $endDate',
                            style: AppTheme.darkTheme.textTheme.bodySmall
                                ?.copyWith(
                              color: AppTheme.textSecondary,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),

                    SizedBox(height: 2.h),

                    // Spending Information
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Spent',
                              style: AppTheme.darkTheme.textTheme.labelSmall
                                  ?.copyWith(
                                color: AppTheme.textSecondary,
                              ),
                            ),
                            Text(
                              '\$${currentSpending.toStringAsFixed(2)}',
                              style: AppTheme.darkTheme.textTheme.titleSmall
                                  ?.copyWith(
                                color: progressColor,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              'Budget',
                              style: AppTheme.darkTheme.textTheme.labelSmall
                                  ?.copyWith(
                                color: AppTheme.textSecondary,
                              ),
                            ),
                            Text(
                              '\$${budget.toStringAsFixed(2)}',
                              style: AppTheme.darkTheme.textTheme.titleSmall
                                  ?.copyWith(
                                color: AppTheme.textPrimary,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),

                    SizedBox(height: 1.5.h),

                    // Progress Bar
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Budget Progress',
                              style: AppTheme.darkTheme.textTheme.labelSmall
                                  ?.copyWith(
                                color: AppTheme.textSecondary,
                              ),
                            ),
                            Text(
                              '${(progressPercentage * 100).toInt()}%',
                              style: AppTheme.darkTheme.textTheme.labelSmall
                                  ?.copyWith(
                                color: progressColor,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 0.5.h),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(4),
                          child: LinearProgressIndicator(
                            value: progressPercentage,
                            backgroundColor: AppTheme.borderColor,
                            valueColor:
                                AlwaysStoppedAnimation<Color>(progressColor),
                            minHeight: 6,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _getCategoryIcon(String category) {
    switch (category.toLowerCase()) {
      case 'business':
        return 'business_center';
      case 'leisure':
        return 'beach_access';
      case 'family':
        return 'family_restroom';
      case 'adventure':
        return 'hiking';
      case 'city':
        return 'location_city';
      case 'nature':
        return 'nature';
      default:
        return 'flight_takeoff';
    }
  }
}

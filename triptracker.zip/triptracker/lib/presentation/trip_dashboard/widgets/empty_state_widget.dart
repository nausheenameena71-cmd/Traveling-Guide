import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class EmptyStateWidget extends StatelessWidget {
  final VoidCallback? onCreateTrip;

  const EmptyStateWidget({
    Key? key,
    this.onCreateTrip,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(8.w),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Travel Illustration
          Container(
            width: 60.w,
            height: 30.h,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  AppTheme.accentColor.withValues(alpha: 0.1),
                  AppTheme.successColor.withValues(alpha: 0.05),
                ],
              ),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Background Icons
                Positioned(
                  top: 4.h,
                  left: 8.w,
                  child: CustomIconWidget(
                    iconName: 'flight_takeoff',
                    color: AppTheme.accentColor.withValues(alpha: 0.3),
                    size: 32,
                  ),
                ),
                Positioned(
                  bottom: 6.h,
                  right: 6.w,
                  child: CustomIconWidget(
                    iconName: 'luggage',
                    color: AppTheme.successColor.withValues(alpha: 0.3),
                    size: 28,
                  ),
                ),
                Positioned(
                  top: 8.h,
                  right: 10.w,
                  child: CustomIconWidget(
                    iconName: 'camera_alt',
                    color: AppTheme.warningColor.withValues(alpha: 0.3),
                    size: 24,
                  ),
                ),

                // Main Icon
                Container(
                  padding: EdgeInsets.all(6.w),
                  decoration: BoxDecoration(
                    color: AppTheme.accentColor.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: CustomIconWidget(
                    iconName: 'explore',
                    color: AppTheme.accentColor,
                    size: 48,
                  ),
                ),
              ],
            ),
          ),

          SizedBox(height: 4.h),

          // Title
          Text(
            'Ready for Your Next Adventure?',
            style: AppTheme.darkTheme.textTheme.headlineSmall?.copyWith(
              color: AppTheme.textPrimary,
              fontWeight: FontWeight.w600,
            ),
            textAlign: TextAlign.center,
          ),

          SizedBox(height: 2.h),

          // Description
          Text(
            'Start tracking your travel expenses by creating your first trip. Keep your budget on track and make every journey memorable.',
            style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
              color: AppTheme.textSecondary,
              height: 1.5,
            ),
            textAlign: TextAlign.center,
          ),

          SizedBox(height: 4.h),

          // Create Trip Button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: onCreateTrip,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.accentColor,
                foregroundColor: AppTheme.textPrimary,
                padding: EdgeInsets.symmetric(vertical: 3.h),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 2,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomIconWidget(
                    iconName: 'add',
                    color: AppTheme.textPrimary,
                    size: 20,
                  ),
                  SizedBox(width: 2.w),
                  Text(
                    'Create Your First Trip',
                    style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
                      color: AppTheme.textPrimary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),

          SizedBox(height: 2.h),

          // Feature Highlights
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildFeatureItem(
                icon: 'receipt',
                label: 'Track Expenses',
                color: AppTheme.successColor,
              ),
              _buildFeatureItem(
                icon: 'analytics',
                label: 'Budget Control',
                color: AppTheme.warningColor,
              ),
              _buildFeatureItem(
                icon: 'share',
                label: 'Export Reports',
                color: AppTheme.accentColor,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFeatureItem({
    required String icon,
    required String label,
    required Color color,
  }) {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.all(3.w),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: CustomIconWidget(
            iconName: icon,
            color: color,
            size: 20,
          ),
        ),
        SizedBox(height: 1.h),
        Text(
          label,
          style: AppTheme.darkTheme.textTheme.labelSmall?.copyWith(
            color: AppTheme.textSecondary,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}

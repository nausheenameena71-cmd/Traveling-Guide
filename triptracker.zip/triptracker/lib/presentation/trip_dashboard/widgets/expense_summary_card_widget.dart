import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class ExpenseSummaryCardWidget extends StatelessWidget {
  final double totalExpenses;
  final double monthlyBudget;
  final int activeTrips;
  final VoidCallback? onTap;

  const ExpenseSummaryCardWidget({
    Key? key,
    required this.totalExpenses,
    required this.monthlyBudget,
    required this.activeTrips,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final double budgetPercentage = monthlyBudget > 0
        ? (totalExpenses / monthlyBudget).clamp(0.0, 1.0)
        : 0.0;

    final Color progressColor = budgetPercentage > 0.8
        ? AppTheme.errorColor
        : budgetPercentage > 0.6
            ? AppTheme.warningColor
            : AppTheme.successColor;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
        padding: EdgeInsets.all(5.w),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              AppTheme.accentColor.withValues(alpha: 0.1),
              AppTheme.successColor.withValues(alpha: 0.05),
            ],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: AppTheme.accentColor.withValues(alpha: 0.3),
            width: 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header Row
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Total Expenses',
                      style: AppTheme.darkTheme.textTheme.labelMedium?.copyWith(
                        color: AppTheme.textSecondary,
                      ),
                    ),
                    SizedBox(height: 0.5.h),
                    Text(
                      '\$${totalExpenses.toStringAsFixed(2)}',
                      style:
                          AppTheme.darkTheme.textTheme.headlineSmall?.copyWith(
                        color: AppTheme.textPrimary,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
                Container(
                  padding: EdgeInsets.all(3.w),
                  decoration: BoxDecoration(
                    color: AppTheme.accentColor.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: CustomIconWidget(
                    iconName: 'account_balance_wallet',
                    color: AppTheme.accentColor,
                    size: 28,
                  ),
                ),
              ],
            ),

            SizedBox(height: 3.h),

            // Stats Row
            Row(
              children: [
                Expanded(
                  child: _buildStatItem(
                    icon: 'trending_up',
                    label: 'Monthly Budget',
                    value: '\$${monthlyBudget.toStringAsFixed(0)}',
                    color: AppTheme.successColor,
                  ),
                ),
                SizedBox(width: 4.w),
                Expanded(
                  child: _buildStatItem(
                    icon: 'flight_takeoff',
                    label: 'Active Trips',
                    value: activeTrips.toString(),
                    color: AppTheme.warningColor,
                  ),
                ),
              ],
            ),

            SizedBox(height: 3.h),

            // Budget Progress
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Monthly Progress',
                      style: AppTheme.darkTheme.textTheme.labelMedium?.copyWith(
                        color: AppTheme.textSecondary,
                      ),
                    ),
                    Text(
                      '${(budgetPercentage * 100).toInt()}%',
                      style: AppTheme.darkTheme.textTheme.labelMedium?.copyWith(
                        color: progressColor,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 1.h),
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(
                    value: budgetPercentage,
                    backgroundColor:
                        AppTheme.borderColor.withValues(alpha: 0.3),
                    valueColor: AlwaysStoppedAnimation<Color>(progressColor),
                    minHeight: 8,
                  ),
                ),
                SizedBox(height: 1.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Remaining: \$${(monthlyBudget - totalExpenses).toStringAsFixed(2)}',
                      style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.textSecondary,
                      ),
                    ),
                    budgetPercentage > 0.8
                        ? Row(
                            children: [
                              CustomIconWidget(
                                iconName: 'warning',
                                color: AppTheme.errorColor,
                                size: 14,
                              ),
                              SizedBox(width: 1.w),
                              Text(
                                'Over Budget',
                                style: AppTheme.darkTheme.textTheme.bodySmall
                                    ?.copyWith(
                                  color: AppTheme.errorColor,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          )
                        : Container(),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem({
    required String icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: AppTheme.surfaceColor.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: AppTheme.borderColor.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: icon,
                color: color,
                size: 16,
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: Text(
                  label,
                  style: AppTheme.darkTheme.textTheme.labelSmall?.copyWith(
                    color: AppTheme.textSecondary,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          SizedBox(height: 1.h),
          Text(
            value,
            style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
              color: AppTheme.textPrimary,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

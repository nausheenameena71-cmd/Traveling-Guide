import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/empty_state_widget.dart';
import './widgets/expense_summary_card_widget.dart';
import './widgets/greeting_header_widget.dart';
import './widgets/trip_card_widget.dart';

class TripDashboard extends StatefulWidget {
  const TripDashboard({Key? key}) : super(key: key);

  @override
  State<TripDashboard> createState() => _TripDashboardState();
}

class _TripDashboardState extends State<TripDashboard>
    with TickerProviderStateMixin {
  int _currentTabIndex = 0;
  bool _isRefreshing = false;
  bool _isSearchVisible = false;
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  List<Map<String, dynamic>> _filteredTrips = [];

  // Mock user data
  final Map<String, dynamic> _userData = {
    "name": "Sarah Johnson",
    "email": "sarah.johnson@email.com",
    "avatar":
        "https://cdn.pixabay.com/photo/2015/03/04/22/35/avatar-659652_640.png",
    "totalExpenses": 2847.50,
    "monthlyBudget": 3500.0,
    "notificationCount": 3,
  };

  // Mock trips data
  final List<Map<String, dynamic>> _tripsData = [
    {
      "id": 1,
      "destination": "Tokyo, Japan",
      "startDate": "Dec 15, 2024",
      "endDate": "Dec 22, 2024",
      "currentSpending": 1250.75,
      "budget": 2000.0,
      "category": "leisure",
      "isActive": true,
      "imageUrl":
          "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=800&h=600&fit=crop",
    },
    {
      "id": 2,
      "destination": "New York City, USA",
      "startDate": "Nov 28, 2024",
      "endDate": "Dec 2, 2024",
      "currentSpending": 890.25,
      "budget": 1200.0,
      "category": "business",
      "isActive": true,
      "imageUrl":
          "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=800&h=600&fit=crop",
    },
    {
      "id": 3,
      "destination": "Paris, France",
      "startDate": "Oct 10, 2024",
      "endDate": "Oct 17, 2024",
      "currentSpending": 706.50,
      "budget": 1500.0,
      "category": "leisure",
      "isActive": false,
      "imageUrl":
          "https://images.unsplash.com/photo-1502602898536-47ad22581b52?w=800&h=600&fit=crop",
    },
    {
      "id": 4,
      "destination": "Bali, Indonesia",
      "startDate": "Jan 5, 2025",
      "endDate": "Jan 15, 2025",
      "currentSpending": 0.0,
      "budget": 1800.0,
      "category": "adventure",
      "isActive": true,
      "imageUrl":
          "https://images.unsplash.com/photo-1537953773345-d172ccf13cf1?w=800&h=600&fit=crop",
    },
  ];

  @override
  void initState() {
    super.initState();
    _filteredTrips = List.from(_tripsData);
    _searchController.addListener(_filterTrips);
    _scrollController.addListener(_handleScroll);
  }

  @override
  void dispose() {
    _searchController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _handleScroll() {
    if (_scrollController.offset <= -100 && !_isSearchVisible) {
      setState(() {
        _isSearchVisible = true;
      });
    }
  }

  void _filterTrips() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredTrips = _tripsData.where((trip) {
        final destination = (trip['destination'] as String).toLowerCase();
        final category = (trip['category'] as String).toLowerCase();
        return destination.contains(query) || category.contains(query);
      }).toList();
    });
  }

  Future<void> _refreshData() async {
    setState(() {
      _isRefreshing = true;
    });

    // Simulate network call
    await Future.delayed(const Duration(seconds: 2));

    // Provide haptic feedback
    HapticFeedback.lightImpact();

    setState(() {
      _isRefreshing = false;
      _filteredTrips = List.from(_tripsData);
    });
  }

  void _showTripContextMenu(Map<String, dynamic> trip) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.dialogColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: AppTheme.borderColor,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              trip['destination'] as String,
              style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 3.h),
            _buildContextMenuItem(
              icon: 'edit',
              title: 'Edit Trip',
              onTap: () {
                Navigator.pop(context);
                // Navigate to edit trip
              },
            ),
            _buildContextMenuItem(
              icon: 'analytics',
              title: 'View Summary',
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/trip-detail');
              },
            ),
            _buildContextMenuItem(
              icon: 'share',
              title: 'Share Trip',
              onTap: () {
                Navigator.pop(context);
                // Implement share functionality
              },
            ),
            _buildContextMenuItem(
              icon: 'delete',
              title: 'Delete Trip',
              color: AppTheme.errorColor,
              onTap: () {
                Navigator.pop(context);
                _showDeleteConfirmation(trip);
              },
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  Widget _buildContextMenuItem({
    required String icon,
    required String title,
    required VoidCallback onTap,
    Color? color,
  }) {
    return ListTile(
      leading: CustomIconWidget(
        iconName: icon,
        color: color ?? AppTheme.textSecondary,
        size: 24,
      ),
      title: Text(
        title,
        style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
          color: color ?? AppTheme.textPrimary,
        ),
      ),
      onTap: onTap,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
      ),
    );
  }

  void _showDeleteConfirmation(Map<String, dynamic> trip) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.dialogColor,
        title: Text(
          'Delete Trip',
          style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Text(
          'Are you sure you want to delete "${trip['destination']}"? This action cannot be undone.',
          style: AppTheme.darkTheme.textTheme.bodyMedium,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: TextStyle(color: AppTheme.textSecondary),
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                _tripsData.removeWhere((t) => t['id'] == trip['id']);
                _filteredTrips.removeWhere((t) => t['id'] == trip['id']);
              });
            },
            child: Text(
              'Delete',
              style: TextStyle(color: AppTheme.errorColor),
            ),
          ),
        ],
      ),
    );
  }

  int get _activeTripsCount {
    return _tripsData.where((trip) => trip['isActive'] as bool).length;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.primaryDark,
      body: SafeArea(
        child: Column(
          children: [
            // Search Bar (Conditional)
            AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              height: _isSearchVisible ? 8.h : 0,
              child: _isSearchVisible
                  ? Container(
                      padding:
                          EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                      child: TextField(
                        controller: _searchController,
                        style: AppTheme.darkTheme.textTheme.bodyMedium,
                        decoration: InputDecoration(
                          hintText: 'Search trips...',
                          prefixIcon: Padding(
                            padding: EdgeInsets.all(3.w),
                            child: CustomIconWidget(
                              iconName: 'search',
                              color: AppTheme.textSecondary,
                              size: 20,
                            ),
                          ),
                          suffixIcon: IconButton(
                            onPressed: () {
                              setState(() {
                                _isSearchVisible = false;
                                _searchController.clear();
                              });
                            },
                            icon: CustomIconWidget(
                              iconName: 'close',
                              color: AppTheme.textSecondary,
                              size: 20,
                            ),
                          ),
                          filled: true,
                          fillColor: AppTheme.surfaceColor,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide.none,
                          ),
                          contentPadding: EdgeInsets.symmetric(
                            horizontal: 4.w,
                            vertical: 1.5.h,
                          ),
                        ),
                      ),
                    )
                  : Container(),
            ),

            // Main Content
            Expanded(
              child: RefreshIndicator(
                onRefresh: _refreshData,
                color: AppTheme.accentColor,
                backgroundColor: AppTheme.surfaceColor,
                child: CustomScrollView(
                  controller: _scrollController,
                  slivers: [
                    // Header
                    SliverToBoxAdapter(
                      child: GreetingHeaderWidget(
                        userName: _userData['name'] as String,
                        notificationCount:
                            _userData['notificationCount'] as int,
                        onProfileTap: () {
                          Navigator.pushNamed(context, '/user-profile');
                        },
                        onNotificationTap: () {
                          // Handle notification tap
                        },
                      ),
                    ),

                    // Expense Summary Card
                    SliverToBoxAdapter(
                      child: ExpenseSummaryCardWidget(
                        totalExpenses: _userData['totalExpenses'] as double,
                        monthlyBudget: _userData['monthlyBudget'] as double,
                        activeTrips: _activeTripsCount,
                        onTap: () {
                          // Navigate to expense overview
                        },
                      ),
                    ),

                    // Section Header
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: EdgeInsets.symmetric(
                            horizontal: 4.w, vertical: 2.h),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Your Trips',
                              style: AppTheme.darkTheme.textTheme.titleLarge
                                  ?.copyWith(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            if (_filteredTrips.isNotEmpty)
                              GestureDetector(
                                onTap: () {
                                  setState(() {
                                    _isSearchVisible = !_isSearchVisible;
                                  });
                                },
                                child: Container(
                                  padding: EdgeInsets.all(2.w),
                                  decoration: BoxDecoration(
                                    color: AppTheme.surfaceColor
                                        .withValues(alpha: 0.7),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: CustomIconWidget(
                                    iconName: 'search',
                                    color: AppTheme.textSecondary,
                                    size: 20,
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),

                    // Trips List or Empty State
                    _filteredTrips.isEmpty
                        ? SliverFillRemaining(
                            child: EmptyStateWidget(
                              onCreateTrip: () {
                                Navigator.pushNamed(context, '/create-trip');
                              },
                            ),
                          )
                        : SliverList(
                            delegate: SliverChildBuilderDelegate(
                              (context, index) {
                                final trip = _filteredTrips[index];
                                return TripCardWidget(
                                  tripData: trip,
                                  onTap: () {
                                    Navigator.pushNamed(
                                        context, '/trip-detail');
                                  },
                                  onAddExpense: () {
                                    Navigator.pushNamed(
                                        context, '/add-expense');
                                  },
                                  onArchive: () {
                                    setState(() {
                                      final tripIndex = _tripsData.indexWhere(
                                        (t) => t['id'] == trip['id'],
                                      );
                                      if (tripIndex != -1) {
                                        _tripsData[tripIndex]['isActive'] =
                                            false;
                                        _filteredTrips = List.from(_tripsData);
                                      }
                                    });
                                  },
                                  onLongPress: () {
                                    HapticFeedback.mediumImpact();
                                    _showTripContextMenu(trip);
                                  },
                                );
                              },
                              childCount: _filteredTrips.length,
                            ),
                          ),

                    // Bottom Spacing
                    SliverToBoxAdapter(
                      child: SizedBox(height: 10.h),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),

      // Bottom Navigation Bar
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: AppTheme.secondaryDark,
          border: Border(
            top: BorderSide(
              color: AppTheme.borderColor.withValues(alpha: 0.3),
              width: 1,
            ),
          ),
        ),
        child: BottomNavigationBar(
          currentIndex: _currentTabIndex,
          onTap: (index) {
            setState(() {
              _currentTabIndex = index;
            });

            switch (index) {
              case 0:
                // Already on dashboard
                break;
              case 1:
                Navigator.pushNamed(context, '/add-expense');
                break;
              case 2:
                Navigator.pushNamed(context, '/user-profile');
                break;
            }
          },
          backgroundColor: AppTheme.secondaryDark,
          selectedItemColor: AppTheme.accentColor,
          unselectedItemColor: AppTheme.textSecondary,
          type: BottomNavigationBarType.fixed,
          elevation: 0,
          items: [
            BottomNavigationBarItem(
              icon: CustomIconWidget(
                iconName: 'dashboard',
                color: _currentTabIndex == 0
                    ? AppTheme.accentColor
                    : AppTheme.textSecondary,
                size: 24,
              ),
              label: 'Dashboard',
            ),
            BottomNavigationBarItem(
              icon: CustomIconWidget(
                iconName: 'receipt_long',
                color: _currentTabIndex == 1
                    ? AppTheme.accentColor
                    : AppTheme.textSecondary,
                size: 24,
              ),
              label: 'Expenses',
            ),
            BottomNavigationBarItem(
              icon: CustomIconWidget(
                iconName: 'person',
                color: _currentTabIndex == 2
                    ? AppTheme.accentColor
                    : AppTheme.textSecondary,
                size: 24,
              ),
              label: 'Profile',
            ),
          ],
        ),
      ),

      // Floating Action Button
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.pushNamed(context, '/create-trip');
        },
        backgroundColor: AppTheme.accentColor,
        foregroundColor: AppTheme.textPrimary,
        elevation: 4,
        icon: CustomIconWidget(
          iconName: 'add',
          color: AppTheme.textPrimary,
          size: 24,
        ),
        label: Text(
          'New Trip',
          style: AppTheme.darkTheme.textTheme.labelLarge?.copyWith(
            color: AppTheme.textPrimary,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    );
  }
}

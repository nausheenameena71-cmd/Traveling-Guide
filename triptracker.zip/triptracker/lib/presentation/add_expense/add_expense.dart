import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // Add this import
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/camera_preview_widget.dart';
import './widgets/expense_form_widget.dart';
import './widgets/receipt_thumbnail_widget.dart';

class AddExpense extends StatefulWidget {
  const AddExpense({Key? key}) : super(key: key);

  @override
  State<AddExpense> createState() => _AddExpenseState();
}

class _AddExpenseState extends State<AddExpense> {
  final _formKey = GlobalKey<FormState>();
  final _amountController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _imagePicker = ImagePicker();

  String _selectedCategory = 'Food';
  String _selectedCurrency = 'USD';
  DateTime _selectedDate = DateTime.now();
  XFile? _capturedImage;
  bool _isLoading = false;
  bool _hasUnsavedChanges = false;

  // Mock trip data for context
  final Map<String, dynamic> _currentTrip = {
    "id": 1,
    "name": "Business Trip to Tokyo",
    "destination": "Tokyo, Japan",
    "startDate": "2025-01-15",
    "endDate": "2025-01-22",
    "budget": 3500.0,
    "currency": "USD",
  };

  @override
  void initState() {
    super.initState();
    _requestPermissions();
    _setupFormListeners();
  }

  @override
  void dispose() {
    _amountController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _requestPermissions() async {
    if (kIsWeb) return;

    await [
      Permission.camera,
      Permission.storage,
    ].request();
  }

  void _setupFormListeners() {
    _amountController.addListener(_onFormChanged);
    _descriptionController.addListener(_onFormChanged);
  }

  void _onFormChanged() {
    if (!_hasUnsavedChanges) {
      setState(() => _hasUnsavedChanges = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        backgroundColor: AppTheme.primaryDark,
        appBar: _buildAppBar(),
        body: _buildBody(),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: AppTheme.primaryDark,
      elevation: 0,
      leading: IconButton(
        onPressed: _onCancelPressed,
        icon: CustomIconWidget(
          iconName: 'close',
          color: AppTheme.textPrimary,
          size: 24,
        ),
      ),
      title: Column(
        children: [
          Text(
            'Add Expense',
            style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
              color: AppTheme.textPrimary,
              fontWeight: FontWeight.w600,
            ),
          ),
          Text(
            _currentTrip['name'],
            style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
              color: AppTheme.textSecondary,
            ),
          ),
        ],
      ),
      centerTitle: true,
      actions: [
        TextButton(
          onPressed: _isLoading ? null : _onSavePressed,
          child: _isLoading
              ? SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    color: AppTheme.accentColor,
                    strokeWidth: 2,
                  ),
                )
              : Text(
                  'Save',
                  style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
                    color: _canSave()
                        ? AppTheme.accentColor
                        : AppTheme.textDisabled,
                    fontWeight: FontWeight.w600,
                  ),
                ),
        ),
      ],
    );
  }

  Widget _buildBody() {
    return SafeArea(
      child: SingleChildScrollView(
        padding: EdgeInsets.all(4.w),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Trip context card
              _buildTripContextCard(),

              SizedBox(height: 3.h),

              // Camera section
              _buildCameraSection(),

              // Receipt thumbnail (if image captured)
              ReceiptThumbnailWidget(
                capturedImage: _capturedImage,
                onRetake: _retakePhoto,
                onEdit: _editPhoto,
                onRemove: _removePhoto,
              ),

              SizedBox(height: 3.h),

              // Expense form
              ExpenseFormWidget(
                amountController: _amountController,
                descriptionController: _descriptionController,
                selectedCategory: _selectedCategory,
                selectedCurrency: _selectedCurrency,
                selectedDate: _selectedDate,
                onCategoryChanged: (category) {
                  setState(() => _selectedCategory = category);
                  _onFormChanged();
                },
                onCurrencyChanged: (currency) {
                  setState(() => _selectedCurrency = currency);
                  _onFormChanged();
                },
                onDateChanged: (date) {
                  setState(() => _selectedDate = date);
                  _onFormChanged();
                },
              ),

              SizedBox(height: 4.h),

              // Save button (full width)
              _buildSaveButton(),

              SizedBox(height: 2.h),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTripContextCard() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.darkTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.accentColor.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: AppTheme.accentColor.withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(8),
            ),
            child: CustomIconWidget(
              iconName: 'flight_takeoff',
              color: AppTheme.accentColor,
              size: 24,
            ),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _currentTrip['destination'],
                  style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
                    color: AppTheme.textPrimary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  '${_currentTrip['startDate']} - ${_currentTrip['endDate']}',
                  style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                    color: AppTheme.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
            decoration: BoxDecoration(
              color: AppTheme.successColor.withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Text(
              'Budget: \$${_currentTrip['budget'].toStringAsFixed(0)}',
              style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                color: AppTheme.successColor,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCameraSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Receipt Photo',
          style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
            color: AppTheme.textPrimary,
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 1.h),
        Text(
          'Capture or select a photo of your receipt for better expense tracking',
          style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
            color: AppTheme.textSecondary,
          ),
        ),
        SizedBox(height: 2.h),
        CameraPreviewWidget(
          onPhotoTaken: _onPhotoTaken,
          onGalleryTap: _selectFromGallery,
        ),
      ],
    );
  }

  Widget _buildSaveButton() {
    return SizedBox(
      width: double.infinity,
      height: 6.h,
      child: ElevatedButton(
        onPressed: _canSave() && !_isLoading ? _onSavePressed : null,
        style: ElevatedButton.styleFrom(
          backgroundColor:
              _canSave() ? AppTheme.accentColor : AppTheme.textDisabled,
          foregroundColor: AppTheme.textPrimary,
          elevation: _canSave() ? 2 : 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: _isLoading
            ? Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      color: AppTheme.textPrimary,
                      strokeWidth: 2,
                    ),
                  ),
                  SizedBox(width: 3.w),
                  Text(
                    'Saving Expense...',
                    style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
                      color: AppTheme.textPrimary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomIconWidget(
                    iconName: 'save',
                    color: AppTheme.textPrimary,
                    size: 24,
                  ),
                  SizedBox(width: 2.w),
                  Text(
                    'Save Expense',
                    style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
                      color: AppTheme.textPrimary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  void _onPhotoTaken(XFile photo) {
    setState(() {
      _capturedImage = photo;
      _hasUnsavedChanges = true;
    });

    // Provide haptic feedback
    if (!kIsWeb) {
      HapticFeedback.lightImpact();
    }

    // Show success message
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(
              iconName: 'check_circle',
              color: AppTheme.successColor,
              size: 20,
            ),
            SizedBox(width: 2.w),
            Text('Receipt photo captured successfully'),
          ],
        ),
        backgroundColor: AppTheme.darkTheme.colorScheme.surface,
        behavior: SnackBarBehavior.floating,
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _selectFromGallery() async {
    try {
      final XFile? image = await _imagePicker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1920,
        maxHeight: 1080,
        imageQuality: 85,
      );

      if (image != null) {
        setState(() {
          _capturedImage = image;
          _hasUnsavedChanges = true;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                CustomIconWidget(
                  iconName: 'photo_library',
                  color: AppTheme.accentColor,
                  size: 20,
                ),
                SizedBox(width: 2.w),
                Text('Photo selected from gallery'),
              ],
            ),
            backgroundColor: AppTheme.darkTheme.colorScheme.surface,
            behavior: SnackBarBehavior.floating,
            duration: Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to select photo from gallery'),
          backgroundColor: AppTheme.errorColor,
        ),
      );
    }
  }

  void _retakePhoto() {
    setState(() => _capturedImage = null);
  }

  void _editPhoto() {
    // In a real app, this would open an image editor
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Photo editing feature coming soon'),
        backgroundColor: AppTheme.darkTheme.colorScheme.surface,
      ),
    );
  }

  void _removePhoto() {
    setState(() {
      _capturedImage = null;
      _hasUnsavedChanges = true;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(
              iconName: 'delete',
              color: AppTheme.errorColor,
              size: 20,
            ),
            SizedBox(width: 2.w),
            Text('Receipt photo removed'),
          ],
        ),
        backgroundColor: AppTheme.darkTheme.colorScheme.surface,
        behavior: SnackBarBehavior.floating,
        duration: Duration(seconds: 2),
      ),
    );
  }

  bool _canSave() {
    return _amountController.text.isNotEmpty &&
        double.tryParse(_amountController.text) != null &&
        double.parse(_amountController.text) > 0;
  }

  Future<void> _onSavePressed() async {
    if (!_canSave() || _isLoading) return;

    setState(() => _isLoading = true);

    try {
      // Simulate API call
      await Future.delayed(Duration(seconds: 2));

      // Create expense data
      final expenseData = {
        "id": DateTime.now().millisecondsSinceEpoch,
        "tripId": _currentTrip['id'],
        "amount": double.parse(_amountController.text),
        "currency": _selectedCurrency,
        "category": _selectedCategory,
        "description": _descriptionController.text.trim(),
        "date": _selectedDate.toIso8601String(),
        "receiptPath": _capturedImage?.path,
        "createdAt": DateTime.now().toIso8601String(),
      };

      // Show success message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              CustomIconWidget(
                iconName: 'check_circle',
                color: AppTheme.successColor,
                size: 20,
              ),
              SizedBox(width: 2.w),
              Text('Expense saved successfully'),
            ],
          ),
          backgroundColor: AppTheme.darkTheme.colorScheme.surface,
          behavior: SnackBarBehavior.floating,
          duration: Duration(seconds: 2),
        ),
      );

      // Navigate back
      Navigator.pop(context, expenseData);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to save expense. Please try again.'),
          backgroundColor: AppTheme.errorColor,
        ),
      );
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  void _onCancelPressed() async {
    if (_hasUnsavedChanges) {
      final shouldDiscard = await _showDiscardDialog();
      if (shouldDiscard == true) {
        Navigator.pop(context);
      }
    } else {
      Navigator.pop(context);
    }
  }

  Future<bool> _onWillPop() async {
    if (_hasUnsavedChanges) {
      final shouldDiscard = await _showDiscardDialog();
      return shouldDiscard ?? false;
    }
    return true;
  }

  Future<bool?> _showDiscardDialog() {
    return showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.dialogColor,
        title: Text(
          'Discard Changes?',
          style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
            color: AppTheme.textPrimary,
          ),
        ),
        content: Text(
          'You have unsaved changes. Are you sure you want to discard them?',
          style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
            color: AppTheme.textSecondary,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(
              'Keep Editing',
              style: TextStyle(color: AppTheme.accentColor),
            ),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text(
              'Discard',
              style: TextStyle(color: AppTheme.errorColor),
            ),
          ),
        ],
      ),
    );
  }
}
import 'dart:convert';
import 'dart:io' if (dart.library.io) 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sizer/sizer.dart';
import 'package:universal_html/html.dart' as html;

import '../../core/app_export.dart';
import './widgets/currency_selector_widget.dart';
import './widgets/profile_header_widget.dart';
import './widgets/profile_photo_picker_widget.dart';
import './widgets/settings_item_widget.dart';
import './widgets/settings_section_widget.dart';

class UserProfile extends StatefulWidget {
  const UserProfile({Key? key}) : super(key: key);

  @override
  State<UserProfile> createState() => _UserProfileState();
}

class _UserProfileState extends State<UserProfile> {
  // User data
  String _userName = 'Sarah Johnson';
  String _userEmail = 'sarah.johnson@email.com';
  String? _profileImageUrl;
  String _selectedCurrency = 'USD';
  bool _notificationsEnabled = true;
  bool _biometricEnabled = false;
  bool _darkThemeEnabled = true;

  // Mock user data for demonstration
  final List<Map<String, dynamic>> _mockTripData = [
    {
      "id": 1,
      "name": "Business Trip to Tokyo",
      "startDate": "2024-12-01",
      "endDate": "2024-12-05",
      "totalExpenses": 2450.75,
      "currency": "USD",
      "expenses": [
        {"category": "Flight", "amount": 1200.00, "date": "2024-12-01"},
        {"category": "Hotel", "amount": 800.00, "date": "2024-12-01"},
        {"category": "Meals", "amount": 350.75, "date": "2024-12-02"},
        {"category": "Transport", "amount": 100.00, "date": "2024-12-03"},
      ]
    },
    {
      "id": 2,
      "name": "Weekend Getaway to Paris",
      "startDate": "2024-11-15",
      "endDate": "2024-11-17",
      "totalExpenses": 1850.50,
      "currency": "EUR",
      "expenses": [
        {"category": "Flight", "amount": 650.00, "date": "2024-11-15"},
        {"category": "Hotel", "amount": 400.00, "date": "2024-11-15"},
        {"category": "Meals", "amount": 280.50, "date": "2024-11-16"},
        {"category": "Shopping", "amount": 520.00, "date": "2024-11-16"},
      ]
    }
  ];

  @override
  void initState() {
    super.initState();
    _loadUserPreferences();
  }

  Future<void> _loadUserPreferences() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      setState(() {
        _userName = prefs.getString('user_name') ?? 'Sarah Johnson';
        _userEmail = prefs.getString('user_email') ?? 'sarah.johnson@email.com';
        _profileImageUrl = prefs.getString('profile_image_url');
        _selectedCurrency = prefs.getString('selected_currency') ?? 'USD';
        _notificationsEnabled = prefs.getBool('notifications_enabled') ?? true;
        _biometricEnabled = prefs.getBool('biometric_enabled') ?? false;
        _darkThemeEnabled = prefs.getBool('dark_theme_enabled') ?? true;
      });
    } catch (e) {
      debugPrint('Error loading preferences: $e');
    }
  }

  Future<void> _saveUserPreferences() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('user_name', _userName);
      await prefs.setString('user_email', _userEmail);
      if (_profileImageUrl != null) {
        await prefs.setString('profile_image_url', _profileImageUrl!);
      }
      await prefs.setString('selected_currency', _selectedCurrency);
      await prefs.setBool('notifications_enabled', _notificationsEnabled);
      await prefs.setBool('biometric_enabled', _biometricEnabled);
      await prefs.setBool('dark_theme_enabled', _darkThemeEnabled);
    } catch (e) {
      debugPrint('Error saving preferences: $e');
    }
  }

  void _showEditProfileDialog() {
    final nameController = TextEditingController(text: _userName);
    final emailController = TextEditingController(text: _userEmail);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.darkTheme.colorScheme.surface,
        title: Text(
          'Edit Profile',
          style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              style: AppTheme.darkTheme.textTheme.bodyLarge,
              decoration: InputDecoration(
                labelText: 'Full Name',
                labelStyle: AppTheme.darkTheme.inputDecorationTheme.labelStyle,
                border: AppTheme.darkTheme.inputDecorationTheme.border,
                enabledBorder:
                    AppTheme.darkTheme.inputDecorationTheme.enabledBorder,
                focusedBorder:
                    AppTheme.darkTheme.inputDecorationTheme.focusedBorder,
                fillColor: AppTheme.darkTheme.inputDecorationTheme.fillColor,
                filled: true,
              ),
            ),
            SizedBox(height: 2.h),
            TextField(
              controller: emailController,
              style: AppTheme.darkTheme.textTheme.bodyLarge,
              keyboardType: TextInputType.emailAddress,
              decoration: InputDecoration(
                labelText: 'Email Address',
                labelStyle: AppTheme.darkTheme.inputDecorationTheme.labelStyle,
                border: AppTheme.darkTheme.inputDecorationTheme.border,
                enabledBorder:
                    AppTheme.darkTheme.inputDecorationTheme.enabledBorder,
                focusedBorder:
                    AppTheme.darkTheme.inputDecorationTheme.focusedBorder,
                fillColor: AppTheme.darkTheme.inputDecorationTheme.fillColor,
                filled: true,
              ),
            ),
            SizedBox(height: 2.h),
            ProfilePhotoPickerWidget(
              onImageSelected: (XFile? image) {
                if (image != null) {
                  setState(() {
                    _profileImageUrl = image.path;
                  });
                  _saveUserPreferences();
                } else {
                  setState(() {
                    _profileImageUrl = null;
                  });
                  _saveUserPreferences();
                }
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: TextStyle(color: AppTheme.textSecondary),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              if (nameController.text.isNotEmpty &&
                  emailController.text.isNotEmpty) {
                setState(() {
                  _userName = nameController.text;
                  _userEmail = emailController.text;
                });
                _saveUserPreferences();
                Navigator.pop(context);
                Fluttertoast.showToast(
                  msg: "Profile updated successfully",
                  toastLength: Toast.LENGTH_SHORT,
                  gravity: ToastGravity.BOTTOM,
                );
              }
            },
            child: Text('Save'),
          ),
        ],
      ),
    );
  }

  void _showCurrencySelector() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => CurrencySelectorWidget(
        selectedCurrency: _selectedCurrency,
        onCurrencySelected: (String currency) {
          setState(() {
            _selectedCurrency = currency;
          });
          _saveUserPreferences();
          Fluttertoast.showToast(
            msg: "Default currency updated to $currency",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
          );
        },
      ),
    );
  }

  Future<void> _exportTripData() async {
    try {
      final String csvContent = _generateCSVContent();
      final String fileName =
          'trip_expenses_export_${DateTime.now().millisecondsSinceEpoch}.csv';

      if (kIsWeb) {
        // Web implementation
        final bytes = utf8.encode(csvContent);
        final blob = html.Blob([bytes]);
        final url = html.Url.createObjectUrlFromBlob(blob);
        final anchor = html.AnchorElement(href: url)
          ..setAttribute("download", fileName)
          ..click();
        html.Url.revokeObjectUrl(url);

        Fluttertoast.showToast(
          msg: "Export downloaded successfully",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
        );
      } else {
        // Mobile implementation
        final directory = await getApplicationDocumentsDirectory();
        final file = File('${directory.path}/$fileName');
        await file.writeAsString(csvContent);

        // Share the file
        await Share.shareXFiles([XFile(file.path)],
            text: 'Trip Expenses Export');

        Fluttertoast.showToast(
          msg: "Export saved and shared successfully",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
        );
      }
    } catch (e) {
      Fluttertoast.showToast(
        msg: "Export failed. Please try again.",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
      );
    }
  }

  String _generateCSVContent() {
    final StringBuffer csv = StringBuffer();
    csv.writeln(
        'Trip Name,Start Date,End Date,Total Expenses,Currency,Category,Amount,Date');

    for (final trip in _mockTripData) {
      final tripName = trip['name'];
      final startDate = trip['startDate'];
      final endDate = trip['endDate'];
      final totalExpenses = trip['totalExpenses'];
      final currency = trip['currency'];

      for (final expense in (trip['expenses'] as List)) {
        csv.writeln(
            '$tripName,$startDate,$endDate,$totalExpenses,$currency,${expense['category']},${expense['amount']},${expense['date']}');
      }
    }

    return csv.toString();
  }

  Future<void> _importTripData() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['csv', 'txt'],
      );

      if (result != null) {
        Fluttertoast.showToast(
          msg: "File imported successfully",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
        );
      }
    } catch (e) {
      Fluttertoast.showToast(
        msg: "Import failed. Please try again.",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
      );
    }
  }

  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.darkTheme.colorScheme.surface,
        title: Text(
          'Logout',
          style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Text(
          'Are you sure you want to logout? All unsaved data will be lost.',
          style: AppTheme.darkTheme.textTheme.bodyLarge,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: TextStyle(color: AppTheme.textSecondary),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pushNamedAndRemoveUntil(
                context,
                '/splash-screen',
                (route) => false,
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.errorColor,
            ),
            child: Text('Logout'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.darkTheme.scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: AppTheme.darkTheme.appBarTheme.backgroundColor,
        elevation: 0,
        title: Text(
          'Profile',
          style: AppTheme.darkTheme.appBarTheme.titleTextStyle,
        ),
        centerTitle: true,
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            margin: EdgeInsets.all(2.w),
            decoration: BoxDecoration(
              color: AppTheme.darkTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Center(
              child: CustomIconWidget(
                iconName: 'arrow_back',
                color: AppTheme.textPrimary,
                size: 5.w,
              ),
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Profile Header
            ProfileHeaderWidget(
              userName: _userName,
              userEmail: _userEmail,
              profileImageUrl: _profileImageUrl,
              onEditProfile: _showEditProfileDialog,
            ),

            SizedBox(height: 2.h),

            // Personal Information Section
            SettingsSectionWidget(
              title: 'Personal Information',
              children: [
                SettingsItemWidget(
                  iconName: 'person',
                  title: 'Edit Profile',
                  subtitle: 'Update your personal information',
                  onTap: _showEditProfileDialog,
                ),
                SettingsItemWidget(
                  iconName: 'attach_money',
                  title: 'Default Currency',
                  subtitle: _selectedCurrency,
                  onTap: _showCurrencySelector,
                  isLast: true,
                ),
              ],
            ),

            // App Preferences Section
            SettingsSectionWidget(
              title: 'App Preferences',
              children: [
                SettingsItemWidget(
                  iconName: 'dark_mode',
                  title: 'Dark Theme',
                  subtitle: 'Always enabled for better experience',
                  trailing: Switch(
                    value: _darkThemeEnabled,
                    onChanged: null, // Disabled as dark theme is always on
                  ),
                ),
                SettingsItemWidget(
                  iconName: 'notifications',
                  title: 'Notifications',
                  subtitle: 'Expense reminders and updates',
                  trailing: Switch(
                    value: _notificationsEnabled,
                    onChanged: (value) {
                      setState(() {
                        _notificationsEnabled = value;
                      });
                      _saveUserPreferences();
                    },
                  ),
                ),
                SettingsItemWidget(
                  iconName: 'fingerprint',
                  title: 'Biometric Authentication',
                  subtitle: 'Use fingerprint or face ID',
                  trailing: Switch(
                    value: _biometricEnabled,
                    onChanged: (value) {
                      setState(() {
                        _biometricEnabled = value;
                      });
                      _saveUserPreferences();
                      Fluttertoast.showToast(
                        msg: value
                            ? "Biometric authentication enabled"
                            : "Biometric authentication disabled",
                        toastLength: Toast.LENGTH_SHORT,
                        gravity: ToastGravity.BOTTOM,
                      );
                    },
                  ),
                  isLast: true,
                ),
              ],
            ),

            // Data Management Section
            SettingsSectionWidget(
              title: 'Data Management',
              children: [
                SettingsItemWidget(
                  iconName: 'file_download',
                  title: 'Export Data',
                  subtitle: 'Download your trip and expense data',
                  onTap: _exportTripData,
                ),
                SettingsItemWidget(
                  iconName: 'file_upload',
                  title: 'Import Data',
                  subtitle: 'Import trip data from CSV file',
                  onTap: _importTripData,
                ),
                SettingsItemWidget(
                  iconName: 'storage',
                  title: 'Storage Usage',
                  subtitle: '2.4 MB used',
                  onTap: () {
                    Fluttertoast.showToast(
                      msg:
                          "Storage details: 2.4 MB used for trip data and receipts",
                      toastLength: Toast.LENGTH_LONG,
                      gravity: ToastGravity.BOTTOM,
                    );
                  },
                  isLast: true,
                ),
              ],
            ),

            // Support Section
            SettingsSectionWidget(
              title: 'Support',
              children: [
                SettingsItemWidget(
                  iconName: 'help',
                  title: 'Help & FAQ',
                  subtitle: 'Get help with using the app',
                  onTap: () {
                    Fluttertoast.showToast(
                      msg: "Help section coming soon",
                      toastLength: Toast.LENGTH_SHORT,
                      gravity: ToastGravity.BOTTOM,
                    );
                  },
                ),
                SettingsItemWidget(
                  iconName: 'feedback',
                  title: 'Send Feedback',
                  subtitle: 'Help us improve the app',
                  onTap: () {
                    Fluttertoast.showToast(
                      msg: "Feedback form coming soon",
                      toastLength: Toast.LENGTH_SHORT,
                      gravity: ToastGravity.BOTTOM,
                    );
                  },
                ),
                SettingsItemWidget(
                  iconName: 'info',
                  title: 'About',
                  subtitle: 'Version 1.0.0',
                  onTap: () {
                    showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        backgroundColor: AppTheme.darkTheme.colorScheme.surface,
                        title: Text(
                          'About TripTracker',
                          style:
                              AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        content: Text(
                          'TripTracker v1.0.0\n\nYour personal travel expense tracking companion. Manage trips, track expenses, and stay within budget.\n\n© 2024 TripTracker',
                          style: AppTheme.darkTheme.textTheme.bodyLarge,
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: Text(
                              'Close',
                              style: TextStyle(color: AppTheme.accentColor),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                  isLast: true,
                ),
              ],
            ),

            // Logout Button
            Container(
              margin: EdgeInsets.all(4.w),
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _showLogoutDialog,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.errorColor,
                  padding: EdgeInsets.symmetric(vertical: 2.h),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomIconWidget(
                      iconName: 'logout',
                      color: AppTheme.textPrimary,
                      size: 5.w,
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      'Logout',
                      style: AppTheme.darkTheme.textTheme.bodyLarge?.copyWith(
                        color: AppTheme.textPrimary,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }
}

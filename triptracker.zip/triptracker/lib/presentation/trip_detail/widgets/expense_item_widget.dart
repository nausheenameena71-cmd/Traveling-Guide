import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class ExpenseItemWidget extends StatelessWidget {
  final Map<String, dynamic> expense;
  final VoidCallback onTap;
  final VoidCallback onDelete;
  final String currency;

  const ExpenseItemWidget({
    Key? key,
    required this.expense,
    required this.onTap,
    required this.onDelete,
    this.currency = '\$',
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final String category = expense['category'] as String? ?? 'other';
    final String title = expense['title'] as String? ?? 'Expense';
    final double amount = (expense['amount'] as num?)?.toDouble() ?? 0.0;
    final String date = expense['date'] as String? ?? '';
    final bool hasReceipt = expense['hasReceipt'] as bool? ?? false;

    return Dismissible(
      key: Key(expense['id'].toString()),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: EdgeInsets.symmetric(horizontal: 4.w),
        decoration: BoxDecoration(
          color: AppTheme.errorColor,
          borderRadius: BorderRadius.circular(8),
        ),
        child: CustomIconWidget(
          iconName: 'delete',
          color: AppTheme.textPrimary,
          size: 24,
        ),
      ),
      onDismissed: (direction) => onDelete(),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
          padding: EdgeInsets.all(3.w),
          decoration: BoxDecoration(
            color: AppTheme.cardColor,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: AppTheme.borderColor,
              width: 1,
            ),
          ),
          child: Row(
            children: [
              Container(
                padding: EdgeInsets.all(2.w),
                decoration: BoxDecoration(
                  color: _getCategoryColor(category).withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: CustomIconWidget(
                  iconName: _getCategoryIcon(category),
                  color: _getCategoryColor(category),
                  size: 20,
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            title,
                            style: AppTheme.darkTheme.textTheme.bodyLarge
                                ?.copyWith(
                              fontWeight: FontWeight.w600,
                            ),
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                          ),
                        ),
                        if (hasReceipt) ...[
                          SizedBox(width: 2.w),
                          CustomIconWidget(
                            iconName: 'receipt',
                            color: AppTheme.accentColor,
                            size: 16,
                          ),
                        ],
                      ],
                    ),
                    SizedBox(height: 0.5.h),
                    Row(
                      children: [
                        Text(
                          _formatCategory(category),
                          style:
                              AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                            color: AppTheme.textSecondary,
                          ),
                        ),
                        Text(
                          ' • ',
                          style:
                              AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                            color: AppTheme.textSecondary,
                          ),
                        ),
                        Text(
                          date,
                          style:
                              AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                            color: AppTheme.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(width: 2.w),
              Text(
                '$currency${amount.toStringAsFixed(2)}',
                style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w700,
                  color: AppTheme.textPrimary,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _getCategoryIcon(String category) {
    switch (category.toLowerCase()) {
      case 'food':
        return 'restaurant';
      case 'transport':
        return 'directions_car';
      case 'accommodation':
        return 'hotel';
      case 'entertainment':
        return 'movie';
      case 'shopping':
        return 'shopping_bag';
      case 'health':
        return 'local_hospital';
      default:
        return 'receipt_long';
    }
  }

  Color _getCategoryColor(String category) {
    switch (category.toLowerCase()) {
      case 'food':
        return AppTheme.warningColor;
      case 'transport':
        return AppTheme.accentColor;
      case 'accommodation':
        return AppTheme.successColor;
      case 'entertainment':
        return const Color(0xFFFF6B6B);
      case 'shopping':
        return const Color(0xFF4ECDC4);
      case 'health':
        return const Color(0xFFFF8A80);
      default:
        return AppTheme.textSecondary;
    }
  }

  String _formatCategory(String category) {
    return category.substring(0, 1).toUpperCase() +
        category.substring(1).toLowerCase();
  }
}

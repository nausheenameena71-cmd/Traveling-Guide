import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class TripInfoWidget extends StatefulWidget {
  final Map<String, dynamic> tripData;
  final Function(Map<String, dynamic>) onUpdate;

  const TripInfoWidget({
    Key? key,
    required this.tripData,
    required this.onUpdate,
  }) : super(key: key);

  @override
  State<TripInfoWidget> createState() => _TripInfoWidgetState();
}

class _TripInfoWidgetState extends State<TripInfoWidget> {
  late TextEditingController _destinationController;
  late TextEditingController _budgetController;
  late TextEditingController _notesController;
  bool _isEditing = false;

  @override
  void initState() {
    super.initState();
    _destinationController = TextEditingController(
      text: widget.tripData['destination'] as String? ?? '',
    );
    _budgetController = TextEditingController(
      text: (widget.tripData['budget'] as num?)?.toString() ?? '',
    );
    _notesController = TextEditingController(
      text: widget.tripData['notes'] as String? ?? '',
    );
  }

  @override
  void dispose() {
    _destinationController.dispose();
    _budgetController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Trip Information',
                style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              GestureDetector(
                onTap: _toggleEdit,
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                  decoration: BoxDecoration(
                    color: _isEditing
                        ? AppTheme.successColor
                        : AppTheme.accentColor,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CustomIconWidget(
                        iconName: _isEditing ? 'check' : 'edit',
                        color: AppTheme.textPrimary,
                        size: 16,
                      ),
                      SizedBox(width: 1.w),
                      Text(
                        _isEditing ? 'Save' : 'Edit',
                        style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                          color: AppTheme.textPrimary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 3.h),
          _buildInfoField(
            'Destination',
            _destinationController,
            'location_on',
            TextInputType.text,
          ),
          SizedBox(height: 2.h),
          _buildInfoField(
            'Start Date',
            TextEditingController(
                text: widget.tripData['startDate'] as String? ?? ''),
            'calendar_today',
            TextInputType.none,
            enabled: false,
          ),
          SizedBox(height: 2.h),
          _buildInfoField(
            'End Date',
            TextEditingController(
                text: widget.tripData['endDate'] as String? ?? ''),
            'event',
            TextInputType.none,
            enabled: false,
          ),
          SizedBox(height: 2.h),
          _buildInfoField(
            'Budget (\$)',
            _budgetController,
            'account_balance_wallet',
            TextInputType.numberWithOptions(decimal: true),
          ),
          SizedBox(height: 2.h),
          _buildInfoField(
            'Notes',
            _notesController,
            'note',
            TextInputType.multiline,
            maxLines: 4,
          ),
          SizedBox(height: 3.h),
          _buildStatsSection(),
        ],
      ),
    );
  }

  Widget _buildInfoField(
    String label,
    TextEditingController controller,
    String iconName,
    TextInputType keyboardType, {
    int maxLines = 1,
    bool enabled = true,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
            color: AppTheme.textSecondary,
            fontWeight: FontWeight.w500,
          ),
        ),
        SizedBox(height: 1.h),
        Container(
          decoration: BoxDecoration(
            color: AppTheme.surfaceColor,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: AppTheme.borderColor,
              width: 1,
            ),
          ),
          child: TextField(
            controller: controller,
            enabled: enabled && _isEditing,
            keyboardType: keyboardType,
            maxLines: maxLines,
            style: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
              color: enabled ? AppTheme.textPrimary : AppTheme.textSecondary,
            ),
            decoration: InputDecoration(
              prefixIcon: Padding(
                padding: EdgeInsets.all(3.w),
                child: CustomIconWidget(
                  iconName: iconName,
                  color: AppTheme.textSecondary,
                  size: 20,
                ),
              ),
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(
                horizontal: 3.w,
                vertical: 2.h,
              ),
              hintText: enabled ? 'Enter $label' : '',
              hintStyle: AppTheme.darkTheme.textTheme.bodyMedium?.copyWith(
                color: AppTheme.textDisabled,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildStatsSection() {
    final int totalExpenses =
        (widget.tripData['expenses'] as List?)?.length ?? 0;
    final double totalAmount = _calculateTotalExpenses();
    final int tripDays = _calculateTripDays();

    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.borderColor,
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Trip Statistics',
            style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Expanded(
                child: _buildStatItem(
                  'Total Expenses',
                  totalExpenses.toString(),
                  'receipt_long',
                ),
              ),
              Expanded(
                child: _buildStatItem(
                  'Trip Duration',
                  '$tripDays days',
                  'schedule',
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          _buildStatItem(
            'Daily Average',
            tripDays > 0
                ? '\$${(totalAmount / tripDays).toStringAsFixed(2)}'
                : '\$0.00',
            'trending_up',
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, String value, String iconName) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            CustomIconWidget(
              iconName: iconName,
              color: AppTheme.accentColor,
              size: 16,
            ),
            SizedBox(width: 2.w),
            Text(
              label,
              style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                color: AppTheme.textSecondary,
              ),
            ),
          ],
        ),
        SizedBox(height: 0.5.h),
        Text(
          value,
          style: AppTheme.darkTheme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w700,
            color: AppTheme.textPrimary,
          ),
        ),
      ],
    );
  }

  void _toggleEdit() {
    if (_isEditing) {
      _saveChanges();
    }
    setState(() {
      _isEditing = !_isEditing;
    });
  }

  void _saveChanges() {
    final updatedData = Map<String, dynamic>.from(widget.tripData);
    updatedData['destination'] = _destinationController.text;
    updatedData['budget'] = double.tryParse(_budgetController.text) ?? 0.0;
    updatedData['notes'] = _notesController.text;

    widget.onUpdate(updatedData);
  }

  double _calculateTotalExpenses() {
    final expenses = widget.tripData['expenses'] as List? ?? [];
    return expenses.fold(0.0, (sum, expense) {
      return sum +
              (((expense as Map<String, dynamic>)['amount'] as num?)
                  ?.toDouble() ??
          0.0);
    });
  }

  int _calculateTripDays() {
    try {
      final startDate =
          DateTime.parse(widget.tripData['startDate'] as String? ?? '');
      final endDate =
          DateTime.parse(widget.tripData['endDate'] as String? ?? '');
      return endDate.difference(startDate).inDays + 1;
    } catch (e) {
      return 0;
    }
  }
}
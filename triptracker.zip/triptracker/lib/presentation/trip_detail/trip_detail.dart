import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/empty_expenses_widget.dart';
import './widgets/expense_item_widget.dart';
import './widgets/trip_header_widget.dart';
import './widgets/trip_info_widget.dart';
import './widgets/trip_summary_card_widget.dart';

class TripDetail extends StatefulWidget {
  const TripDetail({Key? key}) : super(key: key);

  @override
  State<TripDetail> createState() => _TripDetailState();
}

class _TripDetailState extends State<TripDetail> with TickerProviderStateMixin {
  late TabController _tabController;
  final ImagePicker _imagePicker = ImagePicker();
  List<CameraDescription> _cameras = [];
  CameraController? _cameraController;
  bool _isRefreshing = false;

  // Mock trip data
  Map<String, dynamic> _tripData = {
    "id": 1,
    "name": "Tokyo Adventure",
    "destination": "Tokyo, Japan",
    "startDate": "2025-01-15",
    "endDate": "2025-01-22",
    "budget": 2500.0,
    "currency": "\$",
    "notes":
        "Exploring the vibrant culture and cuisine of Tokyo. Don't forget to visit the cherry blossom spots and try authentic ramen.",
    "expenses": [
      {
        "id": 1,
        "title": "Flight Tickets",
        "category": "transport",
        "amount": 850.0,
        "date": "01/15/2025",
        "hasReceipt": true,
      },
      {
        "id": 2,
        "title": "Hotel Booking",
        "category": "accommodation",
        "amount": 120.0,
        "date": "01/15/2025",
        "hasReceipt": true,
      },
      {
        "id": 3,
        "title": "Sushi Dinner",
        "category": "food",
        "amount": 85.0,
        "date": "01/16/2025",
        "hasReceipt": false,
      },
      {
        "id": 4,
        "title": "Tokyo Metro Pass",
        "category": "transport",
        "amount": 25.0,
        "date": "01/16/2025",
        "hasReceipt": true,
      },
      {
        "id": 5,
        "title": "Senso-ji Temple Visit",
        "category": "entertainment",
        "amount": 15.0,
        "date": "01/17/2025",
        "hasReceipt": false,
      },
      {
        "id": 6,
        "title": "Souvenir Shopping",
        "category": "shopping",
        "amount": 150.0,
        "date": "01/18/2025",
        "hasReceipt": true,
      },
    ],
  };

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _initializeCamera();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _cameraController?.dispose();
    super.dispose();
  }

  Future<void> _initializeCamera() async {
    try {
      _cameras = await availableCameras();
      if (_cameras.isNotEmpty) {
        final camera = _cameras.firstWhere(
          (c) => c.lensDirection == CameraLensDirection.back,
          orElse: () => _cameras.first,
        );
        _cameraController = CameraController(
          camera,
          ResolutionPreset.high,
        );
        await _cameraController!.initialize();
      }
    } catch (e) {
      // Camera initialization failed, continue without camera
    }
  }

  Future<bool> _requestCameraPermission() async {
    final status = await Permission.camera.request();
    return status.isGranted;
  }

  Future<void> _captureReceipt() async {
    try {
      if (!await _requestCameraPermission()) {
        _showToast('Camera permission denied');
        return;
      }

      final XFile? image = await _imagePicker.pickImage(
        source: ImageSource.camera,
        imageQuality: 80,
      );

      if (image != null) {
        _showToast('Receipt captured successfully');
        // In a real app, you would save the image and associate it with an expense
      }
    } catch (e) {
      _showToast('Failed to capture receipt');
    }
  }

  Future<void> _selectFromGallery() async {
    try {
      final XFile? image = await _imagePicker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 80,
      );

      if (image != null) {
        _showToast('Image selected successfully');
        // In a real app, you would save the image and associate it with an expense
      }
    } catch (e) {
      _showToast('Failed to select image');
    }
  }

  void _showToast(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: AppTheme.cardColor,
      textColor: AppTheme.textPrimary,
    );
  }

  void _showAddExpenseOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.dialogColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 4,
              decoration: BoxDecoration(
                color: AppTheme.borderColor,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              'Add Expense',
              style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 3.h),
            ListTile(
              leading: Container(
                padding: EdgeInsets.all(2.w),
                decoration: BoxDecoration(
                  color: AppTheme.accentColor.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: CustomIconWidget(
                  iconName: 'camera_alt',
                  color: AppTheme.accentColor,
                  size: 24,
                ),
              ),
              title: Text(
                'Capture Receipt',
                style: AppTheme.darkTheme.textTheme.bodyLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              subtitle: Text(
                'Take a photo of your receipt',
                style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                  color: AppTheme.textSecondary,
                ),
              ),
              onTap: () {
                Navigator.pop(context);
                _captureReceipt();
              },
            ),
            ListTile(
              leading: Container(
                padding: EdgeInsets.all(2.w),
                decoration: BoxDecoration(
                  color: AppTheme.successColor.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: CustomIconWidget(
                  iconName: 'photo_library',
                  color: AppTheme.successColor,
                  size: 24,
                ),
              ),
              title: Text(
                'Select from Gallery',
                style: AppTheme.darkTheme.textTheme.bodyLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              subtitle: Text(
                'Choose an existing photo',
                style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                  color: AppTheme.textSecondary,
                ),
              ),
              onTap: () {
                Navigator.pop(context);
                _selectFromGallery();
              },
            ),
            ListTile(
              leading: Container(
                padding: EdgeInsets.all(2.w),
                decoration: BoxDecoration(
                  color: AppTheme.warningColor.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: CustomIconWidget(
                  iconName: 'add',
                  color: AppTheme.warningColor,
                  size: 24,
                ),
              ),
              title: Text(
                'Manual Entry',
                style: AppTheme.darkTheme.textTheme.bodyLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              subtitle: Text(
                'Add expense details manually',
                style: AppTheme.darkTheme.textTheme.bodySmall?.copyWith(
                  color: AppTheme.textSecondary,
                ),
              ),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/add-expense');
              },
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  void _showMenuOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.dialogColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 4,
              decoration: BoxDecoration(
                color: AppTheme.borderColor,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              'Trip Options',
              style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 3.h),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'file_download',
                color: AppTheme.accentColor,
                size: 24,
              ),
              title: Text(
                'Export Report',
                style: AppTheme.darkTheme.textTheme.bodyLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              onTap: () {
                Navigator.pop(context);
                _exportReport();
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'share',
                color: AppTheme.successColor,
                size: 24,
              ),
              title: Text(
                'Share Trip',
                style: AppTheme.darkTheme.textTheme.bodyLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              onTap: () {
                Navigator.pop(context);
                _shareTrip();
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'edit',
                color: AppTheme.warningColor,
                size: 24,
              ),
              title: Text(
                'Edit Trip',
                style: AppTheme.darkTheme.textTheme.bodyLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/create-trip');
              },
            ),
            ListTile(
              leading: CustomIconWidget(
                iconName: 'delete',
                color: AppTheme.errorColor,
                size: 24,
              ),
              title: Text(
                'Delete Trip',
                style: AppTheme.darkTheme.textTheme.bodyLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: AppTheme.errorColor,
                ),
              ),
              onTap: () {
                Navigator.pop(context);
                _showDeleteConfirmation();
              },
            ),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  void _exportReport() {
    _showToast('Exporting trip report...');
    // In a real app, you would generate and export a PDF report
  }

  void _shareTrip() {
    _showToast('Sharing trip details...');
    // In a real app, you would implement sharing functionality
  }

  void _showDeleteConfirmation() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppTheme.dialogColor,
        title: Text(
          'Delete Trip',
          style: AppTheme.darkTheme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Text(
          'Are you sure you want to delete this trip? This action cannot be undone.',
          style: AppTheme.darkTheme.textTheme.bodyMedium,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: AppTheme.darkTheme.textTheme.labelLarge?.copyWith(
                color: AppTheme.textSecondary,
              ),
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
              _showToast('Trip deleted');
            },
            child: Text(
              'Delete',
              style: AppTheme.darkTheme.textTheme.labelLarge?.copyWith(
                color: AppTheme.errorColor,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _refreshData() async {
    setState(() {
      _isRefreshing = true;
    });

    // Simulate data refresh
    await Future.delayed(const Duration(seconds: 1));

    setState(() {
      _isRefreshing = false;
    });

    _showToast('Data refreshed');
  }

  void _deleteExpense(int expenseId) {
    setState(() {
      final expenses = _tripData['expenses'] as List;
      expenses.removeWhere((expense) => expense['id'] == expenseId);
    });
    _showToast('Expense deleted');
  }

  void _updateTripData(Map<String, dynamic> updatedData) {
    setState(() {
      _tripData = updatedData;
    });
    _showToast('Trip information updated');
  }

  double _calculateTotalExpenses() {
    final expenses = _tripData['expenses'] as List? ?? [];
    return expenses.fold(0.0, (sum, expense) {
      final amount = (expense as Map<String, dynamic>)['amount'];
      final doubleAmount = (amount is num) ? amount.toDouble() : 0.0;
      return sum + doubleAmount;
    });
  }

  @override
  Widget build(BuildContext context) {
    final expenses = _tripData['expenses'] as List? ?? [];
    final totalExpenses = _calculateTotalExpenses();

    return Scaffold(
      backgroundColor: AppTheme.primaryDark,
      body: Column(
        children: [
          TripHeaderWidget(
            tripName: _tripData['name'] as String? ?? 'Trip',
            onBackPressed: () => Navigator.pop(context),
            onMenuPressed: _showMenuOptions,
          ),
          TripSummaryCardWidget(
            destination: _tripData['destination'] as String? ?? '',
            startDate: _tripData['startDate'] as String? ?? '',
            endDate: _tripData['endDate'] as String? ?? '',
            totalExpenses: totalExpenses,
            budget: (_tripData['budget'] as num?)?.toDouble() ?? 0.0,
            currency: _tripData['currency'] as String? ?? '\$',
          ),
          Container(
            margin: EdgeInsets.symmetric(horizontal: 4.w),
            decoration: BoxDecoration(
              color: AppTheme.cardColor,
              borderRadius: BorderRadius.circular(8),
            ),
            child: TabBar(
              controller: _tabController,
              indicator: BoxDecoration(
                color: AppTheme.accentColor,
                borderRadius: BorderRadius.circular(6),
              ),
              indicatorSize: TabBarIndicatorSize.tab,
              dividerColor: Colors.transparent,
              labelColor: AppTheme.textPrimary,
              unselectedLabelColor: AppTheme.textSecondary,
              labelStyle: AppTheme.darkTheme.textTheme.labelLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
              unselectedLabelStyle: AppTheme.darkTheme.textTheme.labelLarge,
              tabs: const [
                Tab(text: 'Expenses'),
                Tab(text: 'Info'),
              ],
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                // Expenses Tab
                expenses.isEmpty
                    ? EmptyExpensesWidget(
                        onAddExpense: _showAddExpenseOptions,
                      )
                    : RefreshIndicator(
                        onRefresh: _refreshData,
                        backgroundColor: AppTheme.cardColor,
                        color: AppTheme.accentColor,
                        child: ListView.builder(
                          padding: EdgeInsets.symmetric(vertical: 2.h),
                          itemCount: expenses.length,
                          itemBuilder: (context, index) {
                            final expense =
                                expenses[index] as Map<String, dynamic>;
                            return ExpenseItemWidget(
                              expense: expense,
                              currency:
                                  _tripData['currency'] as String? ?? '\$',
                              onTap: () {
                                Navigator.pushNamed(context, '/add-expense');
                              },
                              onDelete: () =>
                                  _deleteExpense(expense['id'] as int),
                            );
                          },
                        ),
                      ),
                // Info Tab
                TripInfoWidget(
                  tripData: _tripData,
                  onUpdate: _updateTripData,
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: _tabController.index == 0
          ? FloatingActionButton(
              onPressed: _showAddExpenseOptions,
              backgroundColor: AppTheme.accentColor,
              child: CustomIconWidget(
                iconName: 'add',
                color: AppTheme.textPrimary,
                size: 24,
              ),
            )
          : null,
    );
  }
}

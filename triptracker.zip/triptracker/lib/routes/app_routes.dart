import 'package:flutter/material.dart';
import '../presentation/trip_detail/trip_detail.dart';
import '../presentation/splash_screen/splash_screen.dart';
import '../presentation/trip_dashboard/trip_dashboard.dart';
import '../presentation/user_profile/user_profile.dart';
import '../presentation/create_trip/create_trip.dart';
import '../presentation/add_expense/add_expense.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String tripDetail = '/trip-detail';
  static const String splash = '/splash-screen';
  static const String tripDashboard = '/trip-dashboard';
  static const String userProfile = '/user-profile';
  static const String createTrip = '/create-trip';
  static const String addExpense = '/add-expense';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const SplashScreen(),
    tripDetail: (context) => const TripDetail(),
    splash: (context) => const SplashScreen(),
    tripDashboard: (context) => const TripDashboard(),
    userProfile: (context) => const UserProfile(),
    createTrip: (context) => const CreateTrip(),
    addExpense: (context) => const AddExpense(),
    // TODO: Add your other routes here
  };
}
